
package com.sigie.controller;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/productos")
public class ProductoController {
    @GetMapping
    public String hello() {
        return "Hello SIGIE!";
    }
}
